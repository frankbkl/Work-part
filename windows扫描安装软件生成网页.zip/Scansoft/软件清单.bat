﻿@echo off
:: 不设置 chcp，让它保持系统默认（通常是 GBK 936）
cd /d "%~dp0"

:: 检查是否管理员，不是就自动提权
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo 正在请求管理员权限...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: 以管理员身份运行 PowerShell 脚本
powershell -NoProfile -ExecutionPolicy Bypass -Command "& '%~dp0Scan-Software.ps1'"

:: 如果脚本异常，停留窗口
if %errorlevel% neq 0 pause