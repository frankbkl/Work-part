﻿# ============ 软件清单扫描 + HTML 报表 ============
# 关键：不改变控制台编码，使用系统默认（GBK）
$ErrorActionPreference = 'SilentlyContinue'

$outDir  = Join-Path $env:USERPROFILE "Desktop"
$outFile = Join-Path $outDir "软件清单_$env:COMPUTERNAME_$(Get-Date -Format 'yyyyMMdd_HHmm').html"

# 使用 Write-Host 输出中文（会自动适配控制台编码）
Write-Host "正在扫描已安装软件..." -ForegroundColor Cyan

$apps = Get-ItemProperty `
    HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*,
    HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*,
    HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* |
    Where-Object { $_.DisplayName -and -not $_.SystemComponent } |
    Select-Object DisplayName, DisplayVersion, Publisher, 
                  @{n='InstallDate';e={
                      if ($_.InstallDate -match '^\d{8}$') {
                          try {
                              [datetime]::ParseExact($_.InstallDate,'yyyyMMdd',$null).ToString('yyyy-MM-dd')
                          } catch { $_.InstallDate }
                      } else { $_.InstallDate }
                  }},
                  @{n='EstimatedSize';e={
                      if ($_.EstimatedSize) { '{0:N1} MB' -f ($_.EstimatedSize/1024) } else { '-' }
                  }} |
    Sort-Object DisplayName -Unique

Write-Host "共找到 $($apps.Count) 个软件，正在生成报表..." -ForegroundColor Green

# 加载 Web 编码库
Add-Type -AssemblyName System.Web

# 构建表格行（HTML 转义防止注入）
$rows = ($apps | ForEach-Object {
    $name = [System.Web.HttpUtility]::HtmlEncode($_.DisplayName)
    $ver  = [System.Web.HttpUtility]::HtmlEncode($_.DisplayVersion)
    $pub  = [System.Web.HttpUtility]::HtmlEncode($_.Publisher)
    $date = if ($_.InstallDate) { $_.InstallDate } else { '-' }
    $size = $_.EstimatedSize
    "      <tr><td>$name</td><td>$ver</td><td>$pub</td><td>$date</td><td>$size</td></tr>"
}) -join "`n"

# 获取系统信息
$compInfo = Get-CimInstance Win32_ComputerSystem
$osInfo   = Get-CimInstance Win32_OperatingSystem
$scanTime = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'

# HTML 模板
$html = @"
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>软件清单 - $env:COMPUTERNAME</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Microsoft YaHei', 'Segoe UI', Tahoma, sans-serif; background: #f4f6f9; color: #333; padding: 20px; }
.container { max-width: 1400px; margin: 0 auto; }
.header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); margin-bottom: 20px; }
.header h1 { font-size: 28px; margin-bottom: 10px; font-weight: 600; }
.header .meta { display: flex; flex-wrap: wrap; gap: 20px; font-size: 14px; opacity: 0.95; margin-top: 15px; }
.header .meta div { background: rgba(255,255,255,0.15); padding: 6px 14px; border-radius: 20px; }
.toolbar { background: white; padding: 15px 20px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); margin-bottom: 20px; display: flex; gap: 15px; align-items: center; flex-wrap: wrap; }
.toolbar input { flex: 1; min-width: 200px; padding: 10px 15px; border: 2px solid #e1e5ee; border-radius: 8px; font-size: 14px; outline: none; transition: border 0.2s; }
.toolbar input:focus { border-color: #667eea; }
.stats { color: #667eea; font-weight: 600; font-size: 14px; white-space: nowrap; }
.btn { padding: 10px 20px; background: #667eea; color: white; border: none; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: 500; transition: background 0.2s; }
.btn:hover { background: #5568d3; }
table { width: 100%; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.05); border-collapse: collapse; }
thead { background: #2c3e50; color: white; }
th { padding: 14px; text-align: left; font-weight: 600; font-size: 14px; cursor: pointer; user-select: none; position: relative; }
th:hover { background: #34495e; }
th::after { content: ' ⇅'; opacity: 0.4; font-size: 12px; margin-left: 5px; }
td { padding: 12px 14px; border-bottom: 1px solid #f0f2f5; font-size: 13px; }
tbody tr { transition: background 0.15s; }
tbody tr:hover { background: #f8f9ff; }
tbody tr:nth-child(even) { background: #fafbfc; }
tbody tr:nth-child(even):hover { background: #f8f9ff; }
.footer { text-align: center; color: #999; padding: 20px; font-size: 12px; margin-top: 20px; }
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>📦 已安装软件清单</h1>
    <div class="meta">
      <div>💻 计算机：$env:COMPUTERNAME</div>
      <div>👤 用户：$env:USERNAME</div>
      <div>🖥️ 系统：$($osInfo.Caption)</div>
      <div>🏢 制造商：$($compInfo.Manufacturer) $($compInfo.Model)</div>
      <div>📅 扫描时间：$scanTime</div>
    </div>
  </div>
  
  <div class="toolbar">
    <input type="text" id="search" placeholder="🔍 输入关键字过滤（软件名 / 发行商 / 版本）..." onkeyup="filterTable()">
    <div class="stats">共 <span id="total">$($apps.Count)</span> 个软件 / 显示 <span id="visible">$($apps.Count)</span> 个</div>
    <button class="btn" onclick="exportCSV()">📥 导出 CSV</button>
  </div>
  
  <table id="appTable">
    <thead>
      <tr>
        <th onclick="sortTable(0)" style="width: 35%;">软件名称</th>
        <th onclick="sortTable(1)" style="width: 15%;">版本</th>
        <th onclick="sortTable(2)" style="width: 25%;">发行商</th>
        <th onclick="sortTable(3)" style="width: 15%;">安装日期</th>
        <th onclick="sortTable(4)" style="width: 10%;">大小</th>
      </tr>
    </thead>
    <tbody>
$rows
    </tbody>
  </table>
  
  <div class="footer">
    Generated by PowerShell · $env:COMPUTERNAME · $scanTime
  </div>
</div>

<script>
function filterTable() {
  var q = document.getElementById('search').value.toLowerCase();
  var rows = document.querySelectorAll('#appTable tbody tr');
  var visible = 0;
  rows.forEach(function(r) {
    var text = r.innerText.toLowerCase();
    if (text.indexOf(q) > -1) {
      r.style.display = '';
      visible++;
    } else {
      r.style.display = 'none';
    }
  });
  document.getElementById('visible').innerText = visible;
}

var sortDir = {};
function sortTable(col) {
  var tbody = document.querySelector('#appTable tbody');
  var rows = Array.from(tbody.querySelectorAll('tr'));
  sortDir[col] = !sortDir[col];
  
  rows.sort(function(a, b) {
    var x = a.cells[col].innerText.toLowerCase();
    var y = b.cells[col].innerText.toLowerCase();
    
    // 尝试数字排序
    var numX = parseFloat(x.replace(/[^\d.-]/g, ''));
    var numY = parseFloat(y.replace(/[^\d.-]/g, ''));
    if (!isNaN(numX) && !isNaN(numY)) {
      return sortDir[col] ? numX - numY : numY - numX;
    }
    
    // 字符串排序
    if (x < y) return sortDir[col] ? -1 : 1;
    if (x > y) return sortDir[col] ? 1 : -1;
    return 0;
  });
  
  rows.forEach(function(r) { tbody.appendChild(r); });
}

function exportCSV() {
  var rows = document.querySelectorAll('#appTable tr');
  var csv = [];
  
  rows.forEach(function(r) {
    if (r.style.display === 'none') return;
    var cells = r.querySelectorAll('th, td');
    var line = Array.from(cells).map(function(c) {
      return '"' + c.innerText.replace(/"/g, '""') + '"';
    }).join(',');
    csv.push(line);
  });
  
  var csvContent = '\uFEFF' + csv.join('\r\n');
  var blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = '软件清单_$env:COMPUTERNAME_$(Get-Date -Format "yyyyMMdd").csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
</script>
</body>
</html>
"@

# 使用 UTF-8 with BOM 写入文件（确保浏览器正确识别）
$utf8BOM = New-Object System.Text.UTF8Encoding $true
[System.IO.File]::WriteAllText($outFile, $html, $utf8BOM)

Write-Host ""
Write-Host "报表已生成：$outFile" -ForegroundColor Green
Write-Host "正在打开浏览器..." -ForegroundColor Cyan

Start-Process $outFile

Start-Sleep -Seconds 2