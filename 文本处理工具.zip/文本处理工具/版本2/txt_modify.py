import os
import sys
import tkinter as tk
from tkinter import filedialog, messagebox
import re

def get_executable_dir():
    """获取exe程序所在的目录"""
    if getattr(sys, 'frozen', False):
        # 如果是打包后的exe
        return os.path.dirname(sys.executable)
    else:
        # 如果是直接运行的py文件
        return os.path.dirname(os.path.abspath(__file__))

def count_ones_in_line(line):
    """统计一行中数字1的个数"""
    return line.count('1')

def process_txt_file(input_path, output_folder):
    """处理单个txt文件"""
    try:
        with open(input_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        if len(lines) < 29:
            return False, f"文件行数不足: {input_path}"
        
        # 统计第29行（索引28）中数字1的个数
        ones_count = count_ones_in_line(lines[28])
        
        # 处理第7行（索引6）的BCEQU值
        line7 = lines[6]
        match = re.search(r'BCEQU:(\d+)', line7)
        if match:
            original_value = int(match.group(1))
            new_value = original_value - ones_count
            lines[6] = f'Bin1:{new_value}\n'
        else:
            return False, f"第7行格式不正确: {input_path}"
        
        # 修改第4行（索引3）
        lines[3] = 'NOTCH:DOWN\n'
        
        # 从第13行开始替换 RowData: 为点
        for i in range(12, len(lines)):
            lines[i] = lines[i].replace('RowData:', '.')
        
        # 第29行（索引28）的所有数字1替换为数字4
        lines[28] = lines[28].replace('1', '4')
        
        # 删除第1、5、6、8、9、10、11、12行（从后往前删除，避免索引变化）
        lines_to_delete = [11, 10, 9, 8, 7, 5, 4, 0]  # 索引值
        for idx in lines_to_delete:
            if idx < len(lines):
                del lines[idx]
        
        # 保存修改后的文件
        filename = os.path.basename(input_path)
        output_path = os.path.join(output_folder, filename)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.writelines(lines)
        
        return True, f"成功处理: {filename}"
    
    except Exception as e:
        return False, f"处理失败 {input_path}: {str(e)}"

def select_files_and_process():
    """选择文件或文件夹并处理"""
    root = tk.Tk()
    root.withdraw()
    
    # 询问用户选择文件还是文件夹
    choice = messagebox.askquestion("选择模式", "是否选择文件夹？\n点击'是'选择文件夹，点击'否'选择文件")
    
    txt_files = []
    
    if choice == 'yes':
        # 选择文件夹
        folder_path = filedialog.askdirectory(title="选择包含txt文件的文件夹")
        if not folder_path:
            messagebox.showinfo("提示", "未选择文件夹")
            return
        
        # 获取文件夹中所有txt文件
        for root_dir, dirs, files in os.walk(folder_path):
            for file in files:
                if file.lower().endswith('.txt'):
                    txt_files.append(os.path.join(root_dir, file))
    else:
        # 选择文件
        files = filedialog.askopenfilenames(
            title="选择txt文件",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if not files:
            messagebox.showinfo("提示", "未选择文件")
            return
        txt_files = list(files)
    
    if not txt_files:
        messagebox.showinfo("提示", "未找到txt文件")
        return
    
    # 创建输出文件夹 - 使用修改后的函数获取exe所在目录
    exe_dir = get_executable_dir()
    output_folder = os.path.join(exe_dir, "修改后的文件")
    
    try:
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)
    except Exception as e:
        messagebox.showerror("错误", f"无法创建输出文件夹: {str(e)}")
        return
    
    # 处理所有文件
    success_count = 0
    fail_count = 0
    messages = []
    
    for txt_file in txt_files:
        success, message = process_txt_file(txt_file, output_folder)
        messages.append(message)
        if success:
            success_count += 1
        else:
            fail_count += 1
    
    # 显示处理结果
    result_message = f"处理完成！\n成功: {success_count} 个文件\n失败: {fail_count} 个文件\n\n输出目录: {output_folder}\n\n"
    result_message += "\n".join(messages[:10])  # 只显示前10条消息
    if len(messages) > 10:
        result_message += f"\n... 还有 {len(messages) - 10} 条消息"
    
    messagebox.showinfo("处理结果", result_message)

if __name__ == "__main__":
    select_files_and_process()