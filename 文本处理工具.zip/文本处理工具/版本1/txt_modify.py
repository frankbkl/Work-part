import os
import tkinter as tk
from tkinter import filedialog, messagebox

# 配置：自动生成的文件夹名称
OUTPUT_DIR = "修改后的文件"

def process_text_file(input_file, output_file):
    # 读取原始文件的所有行（保留原始行号 1,2,3...）
    with open(input_file, 'r', encoding='utf-8', errors='ignore') as f:
        original_lines = f.readlines()

    # ==============================================
    # 第一步：按照【原始文件行号】修改内容（不删除任何行）
    # ==============================================
    # 1. 原始第4行 → 强制修改为 NOTCH:DOWN
    if len(original_lines) >= 4:
        original_lines[3] = "NOTCH:DOWN\n"

    # 2. 原始第7行 → 把 BCEQU 替换成 Bin1
    if len(original_lines) >= 7:
        original_lines[6] = original_lines[6].replace("BCEQU", "Bin1")

    # 3. 原始第29行 → 把数字 1 替换成 4
    if len(original_lines) >= 29:
        original_lines[28] = original_lines[28].replace("1", "4")

    # 4. 原始第13行及以后 → 所有 RowData: 替换为 .    
    if len(original_lines) >= 13:
        for i in range(12, len(original_lines)):
            original_lines[i] = original_lines[i].replace("RowData:", ".")

    # ==============================================
    # 第二步：删除【原始文件】指定的行（最后执行，不影响修改）
    # ==============================================
    # 需要删除的原始行号：1、5、6、8、9、10、11、12
    delete_line_numbers = [1, 5, 6, 8, 9, 10, 11, 12]
    # 转换为索引，倒序删除（防止索引错位，核心关键！）
    delete_indexes = sorted([num - 1 for num in delete_line_numbers], reverse=True)
    
    for idx in delete_indexes:
        if 0 <= idx < len(original_lines):
            del original_lines[idx]

    # 写入最终文件
    with open(output_file, 'w', encoding='utf-8', newline='') as f:
        f.writelines(original_lines)

def main():
    # 隐藏主窗口
    root = tk.Tk()
    root.withdraw()

    # 创建输出文件夹
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)

    # 选择TXT文件（支持多选）
    file_paths = filedialog.askopenfilenames(
        title="请选择需要修改的TXT文件",
        filetypes=[("文本文档", "*.txt"), ("所有文件", "*.*")]
    )

    if not file_paths:
        messagebox.showinfo("提示", "未选择任何文件！")
        return

    # 批量处理文件
    success = 0
    for path in file_paths:
        try:
            filename = os.path.basename(path)
            save_path = os.path.join(OUTPUT_DIR, filename)
            process_text_file(path, save_path)
            success += 1
        except Exception as e:
            messagebox.showerror("处理失败", f"文件：{filename}\n错误：{str(e)}")

    messagebox.showinfo("处理完成", f"成功处理 {success} 个文件！\n文件保存在：{OUTPUT_DIR}")

if __name__ == "__main__":
    main()